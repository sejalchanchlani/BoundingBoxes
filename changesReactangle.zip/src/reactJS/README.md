# reactJS
canvasImage=>   
read image from input type='file',     
handleFile => this.tempImg = inputFile,      
myStyle = background-image = {this.state.tempImg}
