import React from 'react';  
import ReactTable from "react-table";  
 
// function Table()  {  
 
//     const data=[
//         {
//               id:1,
//               x1:2,
//               y1:3,
//               x2:2,
//               y2:5,
//               width:25,
//               height:25,
//               area:25,
//               impacttype:1
//         },
//         {
    
//             id:2,
//             x1:2,
//             y1:3,
//             x2:2,
//             y2:5,
//             width:25,
//             height:25,
//             area:25,
//             impacttype:2
//         },
//         {
             
//             id:3,
//             x1:2,
//             y1:3,
//             x2:2,
//             y2:5,
//             width:25,
//             height:25,
//             area:25,
//             impacttype:3
//         }
//     ]

//     const columns=[{
//                     Headers:"id",
//                     accessor:"id"
//                     }]

//         return (  
//           <div>  
//               <ReactTable  
//                   data={data}  
//                   columns={columns} 
//                   defaultPageSize = {2}  
//                   pageSizeOptions = {[2,4, 6]}  
//               />  
              
//           </div>        
//     )  
//   }  
// export default Table;
const data = [
    { name: "Anom", age: 19, gender: "Male" },
    { name: "Megha", age: 19, gender: "Female" },
    { name: "Subham", age: 25, gender: "Male"},
  ]
    
export default function Table() {
    return (
      <div className="App">
        <table>
          <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Gender</th>
          </tr>
          {data.map((val, key) => {
            return (
              <tr key={key}>
                <td>{val.name}</td>
                <td>{val.age}</td>
                <td>{val.gender}</td>
              </tr>
            )
          })}
        </table>
      </div>
    );
  }