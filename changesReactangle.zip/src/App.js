import React from 'react';
import logo from './logo.svg';
import './App.css';
import ParentContainer from './components/ParentContainer';
import ImgZoom from './components/ImgZoom'
import User from '../src/user.json';
import Table from './components/Table';
function App() {
  
  return (
    <div className='App'>
     {/* <Table/> */}
     
      
    <ParentContainer/>
    {/* {
     User && User.map(user=>{
        return(
          <div className="sub">
            {user.name}
            { user.id }
            {user.list && user.list.map(data=>{
              return(
                <div key={data.placeId}>
                   {data.placeId}
                   {data.placeName}
                  </div>
               
              )
            }

            )}
            </div>
        )
      })
    } */}
    
    </div>
  );
}

export default App;
